import { AgentsManager } from '@/components/agents-manager';

export default function AgentsInstalled() {
  return <AgentsManager />;
}

