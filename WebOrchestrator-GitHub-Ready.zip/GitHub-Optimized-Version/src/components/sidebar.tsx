import { cn } from "@/lib/utils";
import {
  BarChart3,
  Play,
  Monitor,
  Bot,
  Database,
  Settings,
  Book,
  Code2,
  MessageSquare,
  Globe,
  CheckSquare,
  Users,
  Search,
  Moon,
  Sun,
  Activity,
  Zap,
  Terminal,
  Plus,
  LayoutDashboard,
} from "lucide-react";
import { GitBranch } from "lucide-react";
import { useEffect, useState } from "react";

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

export function Sidebar({ activeSection, onSectionChange }: SidebarProps) {
  const [theme, setTheme] = useState<string>(() => localStorage.getItem("theme") || "light");
  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") root.classList.add("dark");
    else root.classList.remove("dark");
    localStorage.setItem("theme", theme);
  }, [theme]);

  const menuItems = [
    {
      category: "General",
      items: [
        { id: "overview", label: "Overview", icon: BarChart3 },
        { id: "chat", label: "AI Chat", icon: MessageSquare },
        { id: "form-submission", label: "Form Submission", icon: Bot },
        { id: "tasks", label: "Tasks", icon: CheckSquare },
        { id: "nexus", label: "Nexus AI Workspace", icon: Zap },
        { id: "dev-workspace", label: "Development Workspace", icon: Terminal },
        { id: "computer-use", label: "Playground", icon: Play },
      ],
    },
    {
      category: "Agents",
      items: [
        { id: "agents-dashboard", label: "Dashboard", icon: Activity },
        { id: "agents-marketplace", label: "Marketplace", icon: Globe },
        { id: "agents-create", label: "Create Agent", icon: Plus },
      ],
    },
    {
      category: "Automation",
      items: [
        { id: "sessions", label: "Sessions", icon: Monitor },
        { id: "events", label: "Unified Events", icon: Activity },
        { id: "workflows", label: "Workflows", icon: GitBranch },
        { id: "orchestrator", label: "Task Orchestrator", icon: Bot },
        { id: "profiles", label: "Profiles", icon: Settings },
      ],
    },
    {
      category: "Data Management",
      items: [
        { id: "crm", label: "CRM", icon: Users },
        { id: "data-extraction", label: "Data Extraction", icon: Database, hasSubmenu: true },
      ],
    },
    {
      category: "Resources",
      items: [
        { id: "documentation", label: "Documentation", icon: Book, external: true },
        { id: "cookbook", label: "Web Agents Cookbook", icon: Code2, external: true },
        { id: "community", label: "Discord Community", icon: MessageSquare, external: true },
      ],
    },
    {
      category: "Account",
      items: [
        { id: "settings", label: "Settings", icon: Settings },
      ],
    },
  ] as const;

  return (
    <div className="w-64 bg-sidebar/90 backdrop-blur-sm shadow-lg border-r border-sidebar-border flex flex-col">
      {/* Logo Header */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Globe className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold text-lg text-sidebar-foreground">WebOrchestrator</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              aria-label="Search"
              className="p-2 rounded-md hover:bg-sidebar-accent"
              onClick={() => {
                const event = new CustomEvent("open-command-palette");
                window.dispatchEvent(event);
              }}
            >
              <Search className="w-4 h-4" />
            </button>
            <button
              aria-label="Toggle Theme"
              className="p-2 rounded-md hover:bg-sidebar-accent"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            >
              {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 overflow-y-auto">
        {menuItems.map((section) => (
          <div key={section.category} className="mb-6">
            <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
              {section.category}
            </h3>
            <ul className="space-y-1">
              {section.items.map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => {
                      onSectionChange(item.id);
                    }}
                    className={cn(
                      "flex items-center w-full px-3 py-2 text-sm font-medium rounded-lg transition-colors",
                      activeSection === item.id
                        ? "text-sidebar-primary bg-sidebar-accent"
                        : "text-sidebar-foreground hover:text-sidebar-foreground hover:bg-sidebar-accent"
                    )}
                    data-testid={`sidebar-${item.id}`}
                  >
                    <item.icon className="w-5 h-5 mr-3" />
                    {item.label}
                    {"hasSubmenu" in item && item.hasSubmenu && (
                      <div className="ml-auto">
                        <div className="w-1 h-1 bg-current rounded-full" />
                      </div>
                    )}
                    {"external" in item && item.external && (
                      <div className="ml-auto">
                        <div className="w-3 h-3 border border-current border-r-0 border-t-0 transform rotate-45" />
                      </div>
                    )}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center">
          <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
            <span className="text-white text-sm font-medium">D</span>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-sidebar-foreground">
              Developer
            </p>
            <p className="text-xs text-muted-foreground">
              developer@weborchestrator.com
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
