// Minimal stubs so the UI can build without external package
export const companySchema = {} as any;
export const insertCompanySchema = {} as any;
export const contactSchema = {} as any;
export const insertContactSchema = {} as any;
export const crmListSchema = {} as any;
export const insertCrmListSchema = {} as any;
export const csvUploadResultSchema = {} as any;
export const crmStatsSchema = {} as any;

export type AgentConnection = any;

