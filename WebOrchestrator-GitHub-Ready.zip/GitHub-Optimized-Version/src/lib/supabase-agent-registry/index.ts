export * from '../supabase-agent-registry';
export { supabaseAgentRegistry as default } from '../supabase-agent-registry';

